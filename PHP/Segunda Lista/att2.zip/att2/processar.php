<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dados do contanto</title>
</head>
<body>
    <ul>
        <li><strong>Nome: </strong><?php
    echo $_GET['nome']; ?></li>
        <li><strong>E-mail: </strong><?php
    echo $_GET['email']; ?></li> 
        <li><strong>Telefone: </strong><?php
    echo $_GET['telefone'] ?></li>
    </ul>
</body>
</html>