<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Respostas das perguntas</title>
</head>
<body>

        <strong>Sistema Operacional: </strong><?php
    echo $_GET['sistema_operacional']; ?><br><br>
        <strong>Linguagem: </strong><?php
    echo $_GET['linguagem']; ?><br><br>
        <strong>Melhor time do mundo: </strong><?php
    echo $_GET['vasco'] ?><br><br>

</body>
</html>