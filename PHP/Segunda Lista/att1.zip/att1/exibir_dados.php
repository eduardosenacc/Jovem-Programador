<!DOCTYPE html>
<html>
<head>
    <title>Dados do Usuário</title>
</head>
<body>
    <?php
    
    if (isset($_GET['nome']) && isset($_GET['idade'])) {
        $nome = $_GET['nome'];
        $idade = $_GET['idade'];
        echo "Olá, $nome! Você tem $idade anos.";
    } else {
        echo "Por favor, preencha o formulário.";
    }
    ?>
</body>
</html>