<?php
session_start();

if(isset($_POST['username'],$_POST['password'])){
    if($_POST['username']=='vasco' && $_POST['password']=='chupafotaleza'){
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $_POST['username'];
        echo "Bem vindo, ".$_POST['username'];
    }
    else{
        echo "Credenciais Invalidas";
    }
}
