<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $numeroDeColunas = isset($_POST['numero_de_colunas']) ? intval($_POST['numero_de_colunas']) : 0;
        if ($numeroDeColunas > 0) {
            echo "<h2>Tabela Gerada:</h2>";
            echo "<table border='1'><tr>";
            for ($i = 1; $i <= $numeroDeColunas; $i++) {
                echo "<td>Coluna $i</td>";
            }
            echo "</tr></table>";
        }
    }
    ?>
</body>
</html>
