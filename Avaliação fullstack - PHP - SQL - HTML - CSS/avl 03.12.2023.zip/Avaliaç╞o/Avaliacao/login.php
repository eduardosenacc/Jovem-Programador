<?php
include('conexao.php');

$login = $_POST["login"];
$senha = $_POST["senha"];

$sql = "SELECT * FROM Usuarios
        WHERE login = '{$login}'
        AND senha = '{$senha}'";

$res = $conn->query($sql) or die($conn->error);

$row = $res->fetch_object();

$qtd = $res->num_rows;

if($qtd > 0){
    $_SESSION["login"] = $row->login;
    $_SESSION["tipo"] = $row->tipo;
    print "<script>location.href='dashboard.php';</script>";
}else{
    print "<script>alert('Usuário e/ou senha incorreto(s)');</script>";
    print "<script>location.href='index.php';</script>";
}

?>