CREATE DATABASE avaliacao;

CREATE TABLE usuarios(
ID INT PRIMARY KEY AUTO_INCREMENT,
login VARCHAR(100),
senha VARCHAR (100)
);

INSERT INTO usuarios (login,senha) VALUES ('admin', '123');
INSERT INTO usuarios (login,senha) VALUES ('admin2', '1234');

select * from usuarios;
